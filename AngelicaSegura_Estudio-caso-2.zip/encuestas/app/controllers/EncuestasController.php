<?php
class EncuestasController{

    private $encuestaModel; 
    public function __construct(){
        require_once 'app/models/Encuesta.php';
        $this->encuestaModel = new Encuesta();
    }

    public function index(){
        //session_start(); 
         if (!isset($_SESSION['user_id'])) {
        header('Location: /encuestas/auth/login'); // redirige al login si no está autenticado
        exit();
    }

        $encuestas = $this->encuestaModel->obtenerEncuestasPorCreador($_SESSION['user_id']);
        
        $encuestasOtrosUsuarios = $this->encuestaModel->obtenerEncuestaPorId($_SESSION['user_id']);
        include __DIR__ . '/../views/encuestas/dashboard.php';
    }
    public function crear (){
        include 'app/views/encuestas/crear.php';
    }
    public function guardarEncuesta(){
        $titulo = $_POST['titulo'] ?? '';
        $descripcion = $_POST['descripcion'] ?? '';
        $preguntas = $_POST['preguntas'] ?? [];
        if ($titulo && count($preguntas) > 0) {
            try {
                $id_encuesta = $this->encuestaModel->crearEncuesta($_SESSION['user_id'], $titulo, $descripcion, $preguntas);
                header('Location: /encuestas/encuestas/index');
            } catch (Exception $e) {
                echo "Error al crear la encuesta: " . $e->getMessage();
            }
        } else {
            echo "Agregue al menos una pregunta";
        }
    }

       public function responder($id_encuesta) {
    $encuesta = $this->encuestaModel->obtenerEncuestaPorIdConPreguntas($id_encuesta);
    $preguntas = $encuesta['preguntas'] ?? [];
    include 'app/views/encuestas/responder.php';    
}

    public function guardarRespuestaEncuesta ($id_encuesta){
        $respuestas = $_POST['respuestas'] ?? [];
        $this-> encuestaModel-> guardarRespuestaEncuesta($id_encuesta, $_SESSION['user_id'], $respuestas);
        header ('Location: /encuestas/encuestas/index');
    }

    public function resultados ($id_encuesta){
    $encuesta = $this->encuestaModel->obtenerEncuestaPorIdConPreguntas($id_encuesta);

    $resultados = $this->encuestaModel->obtenerRespuestasEncuesta($id_encuesta);

        include 'app/views/encuestas/resultados.php';
    }
    public function eliminar ($id_encuesta){
        $this->encuestaModel->eliminar($id_encuesta, $_SESSION['user_id']);
        header('Location: /encuestas/encuestas/index');
    }
    public function verEncuesta ($id_creador){
        $encuesta = $this->encuestaModel->obtenerEncuestaPorCreador($id_creador);
        include 'app/view/encuestas/por_creador.php';
    }

}
?>