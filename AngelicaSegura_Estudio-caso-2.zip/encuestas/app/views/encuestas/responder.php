<?php include 'app/views/layouts/header.php'; ?>

<div class="container mt-4">
    <h2><?php echo htmlspecialchars($encuesta['titulo']); ?></h2>
    <p><?php echo htmlspecialchars($encuesta['descripcion']); ?></p>

    <form action="/encuestas/encuestas/guardarRespuestaEncuesta/<?php echo $encuesta['id']; ?>" method="POST">
        <?php foreach ($preguntas as $preg): ?>
            <div class="mb-3">
                <label class="form-label"><?php echo htmlspecialchars($preg['texto_pregunta']); ?></label>
                <?php for ($i=1; $i<=5; $i++): ?>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="respuestas[<?php echo $preg['id']; ?>]" value="<?php echo $i; ?>" required>
                        <label class="form-check-label"><?php echo $i; ?></label>
                    </div>
                <?php endfor; ?>
            </div>
        <?php endforeach; ?>

        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
</div>

<?php include 'app/views/layouts/footer.php'; ?>