<?php include 'app/views/layouts/header.php'; ?>

<div class="container mt-4">
    <h2>Mis Encuestas Creadas</h2>
    <a href="/encuestas/encuestas/crear" class="btn btn-success mb-3">Crear nueva encuesta</a>
    <?php if (count($encuestas) === 0): ?>
        <p>No has creado encuestas aún.</p>
    <?php else: ?>
        <ul class="list-group mb-4">
        <?php foreach ($encuestas as $enc): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <span><?php echo htmlspecialchars($enc['titulo']); ?></span>
                <div>
                    <?php if (!empty($enc['tiene_respuestas'])): ?>
                        <a href="/encuestas/encuestas/resultados/<?php echo $enc['id']; ?>" class="btn btn-info btn-sm">Resultados</a>
                    <?php endif; ?>
                    <a href="/encuestas/encuestas/eliminar/<?php echo $enc['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar encuesta?')">Eliminar</a>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>

    <h2>Encuestas disponibles para Responder</h2>
    <?php if (count($encuestasOtrosUsuarios) === 0): ?>
        <p>No hay encuestas disponibles.</p>
    <?php else: ?>
        <ul class="list-group">
            <?php foreach ($encuestasOtrosUsuarios as $enc): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span><?php echo htmlspecialchars($enc['titulo']); ?></span>
                    <a href="/encuestas/encuestas/responder/<?php echo $enc['id']; ?>" class="btn btn-primary btn-sm">Responder</a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>

<?php include 'app/views/layouts/footer.php'; ?>