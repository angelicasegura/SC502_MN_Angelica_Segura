<?php include 'app/views/layouts/header.php'; ?>





<div class="container container-main">
    <div class="d-flex flex-column align-items-center text-center mb-4">
        <h1 class="display-4"><?= htmlspecialchars($encuesta['titulo'] ?? 'Título no disponible') ?></h1>
        <p class="lead text-muted"> Descripcion: <?= htmlspecialchars($encuesta['descripcion'] ?? '') ?></p>
    </div>

    <form method="POST" action="/encuestas/encuestas/eliminar/<?= $encuesta['id'] ?? '' ?>" onsubmit="return confirm('¿Seguro que deseas eliminar esta encuesta?');">
        <button type="submit" class="btn btn-danger mb-4">Eliminar Encuesta</button>
    </form>

    
        <?php foreach ($resultados as $pregunta_id => $pregunta): ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($pregunta['texto_pregunta']) ?></h5>
                    <?php  $totalRespuestas = array_sum($pregunta['totales'] ?? []);?>
                    <h6 class="card-subtitle mb-2 text-muted">Total de respuestas: <?= $totalRespuestas ?></h6>
                    <ul class="list-group list-group-flush mt-3">
                        <?php  $maxOpcion = max(array_keys($pregunta['totales']));
                        for ($i = 1; $i <= max(5, $maxOpcion); $i++): 
                            $cantidad = $pregunta['totales'][$i] ?? 0;
                        ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                 <?= $i ?>
                                <span ><?= $cantidad ?></span>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </div>
            </div>
        <?php endforeach; ?>
    
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>


<?php include 'app/views/layouts/footer.php'; ?>
