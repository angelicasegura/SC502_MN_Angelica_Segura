<?php include 'app/views/layouts/header.php'; ?>

<div class="container mt-4">
    <h2>Crear Encuesta</h2>
    <form action="/encuestas/encuestas/guardarEncuesta" method="POST">
        <div class="mb-3">
            <label class="form-label">Título</label>
            <input type="text" name="titulo" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control"></textarea>
        </div>

        <div id="preguntasContainer">
            <div class="mb-3">
                <label class="form-label">Pregunta</label>
                <input type="text" name="preguntas[]" class="form-control" required>
            </div>
        </div>

        <button type="button" id="addPregunta" class="btn btn-secondary mb-3">Agregar pregunta</button>
        <br>
        <button type="submit" class="btn btn-primary">Guardar Encuesta</button>
    </form>
</div>

<script>
document.getElementById('addPregunta').addEventListener('click', function() {
    let container = document.getElementById('preguntasContainer');
    let div = document.createElement('div');
    div.classList.add('mb-3');
    div.innerHTML = '<label class="form-label">Pregunta</label><input type="text" name="preguntas[]" class="form-control" required>';
    container.appendChild(div);
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>


<?php include 'app/views/layouts/footer.php'; ?>