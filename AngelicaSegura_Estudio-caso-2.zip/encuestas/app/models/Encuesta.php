<?php
class Encuesta{
    private $pdo; 

    public function __construct() {
        $this->pdo = getPDOConnection();
    }

    public function crearEncuesta($id_creador, $nombre, $descripcion, $preguntas) {
        $this->pdo->beginTransaction();
        try {
             $stmt =$this-> pdo ->prepare ("INSERT INTO encuestas (id_creador, titulo, descripcion) VALUES (?,?,?)");
            $stmt->execute([$id_creador, $nombre, $descripcion]);
            $id_encuesta = $this->pdo->lastInsertId();
            foreach ($preguntas as $texto_pregunta){
                $stmtP = $this->pdo->prepare("INSERT INTO preguntas (id_encuesta, texto_pregunta) VALUES (?,?)");
                $stmtP->execute ([$id_encuesta, $texto_pregunta]);
            }
                $this->pdo->commit();
                return $id_encuesta;
        }catch (Exception $e) {
            $this->pdo->rollBack();
           throw $e;
        }
    }
    public function obtenerEncuestasPorCreador($id_creador) {
        $stmt = $this->pdo->prepare("SELECT * FROM encuestas WHERE id_creador = ?");
        $stmt->execute([$id_creador]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
        public function obtenerEncuestaPorId($id_usuario) {
        $stmt = $this->pdo->prepare("SELECT * FROM encuestas WHERE id != ?");
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPreguntasEncuesta ($id_encuesta){
        $stmt =$this->pdo->prepare("SELECT * FROM preguntas WHERE id_encuesta = ?");
        $stmt->execute([$id_encuesta]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
        public function obtenerEncuestaPorIdConPreguntas($id_encuesta) {
        $stmt = $this->pdo->prepare("SELECT * FROM encuestas WHERE id = ?");
        $stmt->execute([$id_encuesta]);     
        $encuesta = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($encuesta) {
            $encuesta['preguntas'] = $this->obtenerPreguntasEncuesta($id_encuesta);
            return $encuesta;
        }
        return null;

    }
    public function guardarRespuestaEncuesta($id_encuesta, $id_usuario, $respuestas){
        $this->pdo->beginTransaction();
        try{
            $stmt=$this->pdo->prepare("INSERT INTO participantes (id_encuesta, id_usuario) VALUES (?, ?)");
            $stmt->execute([$id_encuesta, $id_usuario]);
            foreach ($respuestas as $id_pregunta => $respuesta) {
                $stmtR = $this->pdo->prepare("INSERT INTO respuestas (id_pregunta, id_usuario, valor_respuesta) VALUES (?, ?, ?)");
                $stmtR->execute([ $id_pregunta, $id_usuario, $respuesta]);
            }
                $this->pdo->commit();
        }catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
    public function obtenerRespuestasEncuesta($id_encuesta) {
    $preguntas = $this->obtenerPreguntasEncuesta($id_encuesta);
    $resultados = [];
    foreach ($preguntas as $pregunta) {
        $id_pregunta = $pregunta['id'];

        $stmt = $this->pdo->prepare("
            SELECT valor_respuesta, COUNT(*) as total
            FROM respuestas
            WHERE id_pregunta = ?
            GROUP BY valor_respuesta
        ");
        $stmt->execute([$id_pregunta]);
        $totales = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); 
        $resultados[$id_pregunta] = [
            'texto_pregunta' => $pregunta['texto_pregunta'],
            'totales' => $totales
        ];
    }

    return $resultados;
    }
        public function eliminar($id_encuesta, $id_usuario) {
        $stmt = $this->pdo->prepare("DELETE FROM encuestas WHERE id = ? and id_creador = ?");
        return $stmt->execute([$id_encuesta, $id_usuario]);
    }
}
?>