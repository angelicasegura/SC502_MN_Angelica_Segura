const wishForm = document.getElementById("wishForm");
const wishInput = document.getElementById("wishInput");
const wishList = document.getElementById("wishList");

// Enlistar
async function loadWishes() {
  wishList.innerHTML = "";
  try {
    const response = await fetch("api.php");
    const wishes = await response.json();

    if (wishes.length === 0) {
      const empty = document.createElement("li");
      empty.className = "list-group-item text-muted text-center";
      empty.textContent = "No hay deseos agregados.";
      wishList.appendChild(empty);
      return;
    }

    wishes.forEach((wish) => {
      const li = document.createElement("li");
      li.className =
        "list-group-item d-flex justify-content-between align-items-start flex-column flex-sm-row";
      li.innerHTML = `
        <div>
          <strong>${wish.descripcion}</strong><br>
          <small class="text-muted">Agregado el: ${new Date(wish.fecha).toLocaleString("es-ES")}</small>
        </div>
  <button class="btn btn-sm btn-outline-primary mt-2 mt-sm-0" onclick='editWish(${JSON.stringify(wish)})'>Editar</button>
        <button class="btn btn-sm btn-outline-danger mt-2 mt-sm-0" onclick="deleteWish(${wish.id})">Eliminar</button>

      `;
      wishList.appendChild(li);
    });
  } catch (error) {
    console.error("Error al cargar deseos:", error);
  }
}

// Agregar
wishForm.addEventListener("submit", async function (e) {
  e.preventDefault();
  const descripcion = wishInput.value.trim();

  if (descripcion !== "") {

    await fetch("api.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ descripcion }),
    });

    wishInput.value = "";
    loadWishes();
  }
});

// Eliminar
async function deleteWish(id) {
  await fetch("api.php", {
    method: "DELETE",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${id}`,
  });

  loadWishes();
}
//Editar
function editWish(wish) {
   document.getElementById("editId").value = wish.id;
  document.getElementById("editDescripcion").value = wish.descripcion;

  const modalEl = document.getElementById("editModal");
const editModal = new bootstrap.Modal(modalEl);
editModal.show();

  } 

// Guardar cambios hechchos 
document.getElementById("editForm").addEventListener("submit", async e => {
  e.preventDefault();

  const id = document.getElementById("editId").value;
  const descripcion = document.getElementById("editDescripcion").value.trim();

  await fetch("api.php", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, descripcion }),
    });

    

    // Cerrar modal con bootstrap
    const modalEl = document.getElementById("editModal");
    const modal = bootstrap.Modal.getInstance(modalEl);
    modal.hide();

    // Recargar lista de deseos (tú debes tener esta función)
    loadWishes();

  });
 






loadWishes();
