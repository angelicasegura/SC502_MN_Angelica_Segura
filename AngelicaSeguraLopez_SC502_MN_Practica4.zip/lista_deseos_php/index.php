
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Lista de Deseos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container py-5">
    <h1 class="mb-4 text-center">Lista de Deseos</h1>

    <form id="wishForm" class="row g-3">
      <div class="col-md-10">
        <input type="text" id="wishInput" class="form-control" placeholder="Escribe tu deseo..." required>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-primary w-100">Agregar</button>
      </div>
    </form>

    <ul id="wishList" class="list-group mt-4">
      <!-- Deseos -->
    </ul>
    <!-- Modal de edición -->
<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="editForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Editar Deseo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" ></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="editId">
        <div class="mb-3">
          <label for="editDescripcion" class="form-label">Descripción</label>
          <input type="text" id="editDescripcion" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      </div>
    </form>
  </div>
</div>

  </div>
 

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script src="js/deseos.js"></script>


</body>
</html>
